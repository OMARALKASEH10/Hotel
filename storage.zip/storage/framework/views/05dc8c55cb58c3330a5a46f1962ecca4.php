<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <style>
        .top-bar, footer, .footer { display: none !important; }
        .navbar-nav, .nav-links-container { display: none !important; }
        .nav-link[href*="#"] { display: none !important; }
    </style>

    <div class="container py-5">

        <h2 class="fw-bold mb-4">
            <?php echo e(isset($campaign) ? 'تعديل الحملة' : 'إنشاء حملة جديدة'); ?>

        </h2>

        <form action="<?php echo e(isset($campaign) ? route('admin.giveaway.campaign.update', $campaign->id) : route('admin.giveaway.campaign.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if(isset($campaign)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <!-- اسم الحملة -->
            <div class="mb-3">
                <label class="form-label">اسم الحملة</label>
                <input type="text" name="name" class="form-control" required
                       value="<?php echo e(isset($campaign) ? old('name', $campaign->name) : old('name')); ?>">
            </div>

            <!-- وصف الحملة -->
            <div class="mb-3">
                <label class="form-label">الوصف</label>
                <textarea name="description" class="form-control"><?php echo e(isset($campaign) ? old('description', $campaign->description) : old('description')); ?></textarea>
            </div>

            <!-- تاريخ البداية -->
            <div class="mb-3">
                <label class="form-label">تاريخ البداية</label>
                <input type="datetime-local" name="start_date" class="form-control" required
                       value="<?php echo e(isset($campaign) ? \Carbon\Carbon::parse($campaign->start_date)->format('Y-m-d\TH:i') : old('start_date')); ?>">
            </div>

            <!-- تاريخ النهاية -->
            <div class="mb-3">
                <label class="form-label">تاريخ النهاية</label>
                <input type="datetime-local" name="end_date" class="form-control" required
                       value="<?php echo e(isset($campaign) ? \Carbon\Carbon::parse($campaign->end_date)->format('Y-m-d\TH:i') : old('end_date')); ?>">
            </div>

            <!-- حالة السحب (للتعديل فقط) -->
            <?php if(isset($campaign)): ?>
                <div class="mb-3 form-check">
                    <input type="hidden" name="draw_done" value="0">
                    <input type="checkbox" class="form-check-input" name="draw_done" value="1" <?php echo e($campaign->draw_done ? 'checked' : ''); ?>>
                    <label class="form-check-label">تم السحب؟</label>
                </div>
            <?php endif; ?>

            <button class="btn btn-success">
                <?php echo e(isset($campaign) ? 'تحديث الحملة' : 'إنشاء الحملة'); ?>

            </button>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-secondary">رجوع</a>
        </form>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\HP\hotel_booking\resources\views/admin/giveawaycampaign/form.blade.php ENDPATH**/ ?>