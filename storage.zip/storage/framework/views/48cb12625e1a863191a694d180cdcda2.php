<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<style>
    .top-bar, footer, .footer { display: none !important; }
    .navbar-nav, .nav-links-container { display: none !important; }
    .nav-link[href*="#"] { display: none !important; }
</style>

<div class="container py-5 text-center">
    <h1 class="fw-bold text-success mb-5">🎉 الفائز بالسحب 🎉</h1>

    <?php if($campaign->winner): ?>
        <?php
            $winner = $campaign->winner;
        ?>

        <div class="mt-4 p-5 bg-white rounded-4 shadow-lg border-0 animate__animated animate__zoomIn">
            <div class="winner-highlight">
                <h2 class="fw-bold text-dark m-0"><?php echo e($winner->name); ?></h2>
            </div>

            <div class="mt-4 d-flex justify-content-center align-items-center gap-3 flex-wrap">
                
                <span class="phone-highlight fs-5">
                    <i class="fas fa-phone-alt ms-2"></i>
                    <?php echo e($winner->phone); ?>

                </span>

                
                <a
                    href="https://wa.me/218<?php echo e(ltrim($winner->phone, '0')); ?>?text=مبروك 🎉 لقد فزت في السحب"
                    target="_blank"
                    class="btn btn-success rounded-pill px-4 shadow-sm fw-bold"
                >
                    <i class="fab fa-whatsapp ms-2"></i>
                    اتصل عبر واتساب
                </a>
            </div>

            <hr class="my-4 mx-auto" style="width: 50%;">

            <h4 class="fw-bold text-primary animate__animated animate__pulse animate__infinite">
                🎁 3 ليالي إقامة مجانية
            </h4>
        </div>

    <?php else: ?>
        <form action="<?php echo e(route('admin.giveaway.draw.execute', $campaign->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-success btn-lg px-5 rounded-pill shadow-sm">
                🎯 تنفيذ السحب الآن
            </button>
        </form>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.giveaway')); ?>" class="btn btn-outline-success btn-lg mt-5 px-5 rounded-pill shadow-sm">
        ⬅ العودة للمشاركين
    </a>
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\HP\hotel_booking\resources\views/admin/winner.blade.php ENDPATH**/ ?>