<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        body {
            background: #f4f6f9;
        }

        .container {
            max-width: 900px;
            margin-top: 50px;
        }

        h2 {
            color: #1e3a5f;
        }

        .card {
            background: #ffffff;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }

        .input-group-text {
            background-color: #f4f6f9;
            border: 1px solid #ced4da;
            font-weight: 600;
        }

        .form-select, .form-control {
            border-radius: 8px;
        }

        .btn-primary {
            background-color: #1e3a5f;
            border: none;
            padding: 10px 25px;
            border-radius: 8px;
            font-weight: 600;
        }

        .alert-info {
            background-color: #e7f3ff;
            border-color: #b3d7ff;
            color: #055160;
        }
    </style>

    <style>
    .top-bar, footer, .footer { display: none !important; }
    .navbar-nav, .nav-links-container { display: none !important; }
    .nav-link[href*="#"] { display: none !important; }
    </style>

    <div class="container">
        <h2 class="mb-4">إعدادات الفندق</h2>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="card">
                <h5 class="mb-3 fw-bold">رقم الهاتف الرئيسي</h5>
                <input type="text" name="phone" class="form-control" value="<?php echo e($phone); ?>" required>
            </div>

            <div class="card">
                <h5 class="mb-3 fw-bold">أيام وساعات العمل</h5>

                <div class="row g-3 align-items-center">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">أيام العمل</label>
                        <div class="d-flex gap-2">
                            <select name="day_from" class="form-select" required>
                                <?php $__currentLoopData = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($day); ?>" <?php if($day == $day_from): ?> selected <?php endif; ?>><?php echo e($day); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <span class="align-self-center">إلى</span>

                            <select name="day_to" class="form-select" required>
                                <?php $__currentLoopData = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($day); ?>" <?php if($day == $day_to): ?> selected <?php endif; ?>><?php echo e($day); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">ساعات العمل</label>
                        <div class="d-flex gap-2">
                            <!-- وقت البداية -->
                            <select name="time_from_hour" class="form-select" required>
                                <?php for($h=1;$h<=12;$h++): ?>
                                    <option value="<?php echo e($h); ?>" <?php if($h==$time_from_hour): ?> selected <?php endif; ?>><?php echo e($h); ?></option>
                                <?php endfor; ?>
                            </select>
                            <span class="align-self-center">:</span>
                            <select name="time_from_minute" class="form-select" required>
                                <?php for($m=0;$m<60;$m+=5): ?>
                                    <option value="<?php echo e(str_pad($m,2,'0',STR_PAD_LEFT)); ?>" <?php if($m==$time_from_minute): ?> selected <?php endif; ?>><?php echo e(str_pad($m,2,'0',STR_PAD_LEFT)); ?></option>
                                <?php endfor; ?>
                            </select>
                            <select name="time_from_ampm" class="form-select" required>
                                <option value="AM" <?php if($time_from_ampm=='AM'): ?> selected <?php endif; ?>>AM</option>
                                <option value="PM" <?php if($time_from_ampm=='PM'): ?> selected <?php endif; ?>>PM</option>
                            </select>

                            <!-- وقت النهاية -->
                            <span class="align-self-center mx-2">إلى</span>

                            <select name="time_to_hour" class="form-select" required>
                                <?php for($h=1;$h<=12;$h++): ?>
                                    <option value="<?php echo e($h); ?>" <?php if($h==$time_to_hour): ?> selected <?php endif; ?>><?php echo e($h); ?></option>
                                <?php endfor; ?>
                            </select>
                            <span class="align-self-center">:</span>
                            <select name="time_to_minute" class="form-select" required>
                                <?php for($m=0;$m<60;$m+=5): ?>
                                    <option value="<?php echo e(str_pad($m,2,'0',STR_PAD_LEFT)); ?>" <?php if($m==$time_to_minute): ?> selected <?php endif; ?>><?php echo e(str_pad($m,2,'0',STR_PAD_LEFT)); ?></option>
                                <?php endfor; ?>
                            </select>
                            <select name="time_to_ampm" class="form-select" required>
                                <option value="AM" <?php if($time_to_ampm=='AM'): ?> selected <?php endif; ?>>AM</option>
                                <option value="PM" <?php if($time_to_ampm=='PM'): ?> selected <?php endif; ?>>PM</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="alert alert-info mt-3">
                    <small>
                        القيمة الحالية: من <?php echo e($day_from); ?> إلى <?php echo e($day_to); ?> :
                        <?php
                            $hours = explode('-', $working_hours);
                            $start = date("g:i A", strtotime($hours[0]));
                            $end = date("g:i A", strtotime($hours[1]));
                        ?>
                        <?php echo e($start); ?> - <?php echo e($end); ?>

                    </small>
                </div>
            </div>

            <button class="btn btn-primary mt-3">حفظ التغييرات</button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\HP\hotel_booking\resources\views/admin/editPhoneNumber.blade.php ENDPATH**/ ?>