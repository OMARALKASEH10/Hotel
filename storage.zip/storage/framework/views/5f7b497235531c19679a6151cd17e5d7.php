<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<style>
    body {
        background: #f4f6f9;
    }

    .container {
        max-width: 1200px;
        margin-top: 40px;
    }

    h2, h4, h5 {
        color: #1e3a5f;
    }

    .card {
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        transition: transform 0.2s;
        cursor: pointer;
    }

    .card:hover {
        transform: translateY(-5px);
    }

    .card-body h5 {
        font-weight: 600;
        margin-bottom: 10px;
    }

    .card-body h2 {
        font-size: 2rem;
        color: #1e3a5f;
    }

    .btn-primary, .btn-outline-primary, .btn-warning, .btn-success {
        border-radius: 8px;
        font-weight: 600;
        padding: 8px 20px;
    }

    .top-info p {
        font-weight: 600;
        color: #155724;
    }

    .table thead th {
        vertical-align: middle;
        text-align: center;
    }

    .table tbody td {
        vertical-align: middle;
        text-align: center;
    }

    .card-header-custom {
        background: #1e3a5f;
        color: white;
        border-radius: 10px 10px 0 0;
        padding: 8px 15px;
    }

</style>

    <style>
    .top-bar, footer, .footer { display: none !important; }
    .navbar-nav, .nav-links-container { display: none !important; }
    .nav-link[href*="#"] { display: none !important; }
    </style>

<div class="container py-5">

<div class="mb-4 text-start">
        <h2 class="fw-bold mb-2">لوحة التحكم</h2>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-primary shadow-sm">
            🏠 العودة للصفحة الرئيسية
        </a>
    </div>

    <!-- معلومات الفندق -->
    <div class="row g-4 mb-5">
        <div class="col-md-6">
            <div class="card p-3">
                <h5 class="fw-bold">📞 الرقم الرئيسي للفندق</h5>
                <p><?php echo e($phone); ?></p>
            </div>
        </div>
<div class="col-md-6">
    <div class="card p-3">
        <h5 class="fw-bold">⏰ أيام وساعات العمل</h5>
        <p><?php echo e($working_schedule); ?></p>
        <a href="<?php echo e(route('admin.settings')); ?>" class="btn btn-outline-primary btn-sm mt-2">✏️ تعديل الإعدادات</a>
    </div>
</div>

    </div>

<!-- كروت الإحصائيات + الأدمن -->
<div class="row g-4 mb-5">

    <!-- الرسائل -->
    <div class="col-md-4">
        <a href="<?php echo e(route('admin.messages')); ?>" class="text-decoration-none">
            <div class="card text-center p-3">
                <div class="card-body">
                    <h5>📩 الرسائل</h5>
                    <h2><?php echo e($messagesCount); ?></h2>
                </div>
            </div>
        </a>
    </div>

    <!-- المشاركين -->
    <div class="col-md-4">
        <a href="<?php echo e(route('admin.giveaway')); ?>" class="text-decoration-none">
            <div class="card text-center p-3">
                <div class="card-body">
                    <h5>🎉 المشاركين</h5>
                    <h2><?php echo e($entriesCount); ?></h2>
                </div>
            </div>
        </a>
    </div>

    <!-- الأدمن الحالي -->
    <div class="col-md-4">
        <div class="card text-center p-3 h-100">
            <div class="card-body d-flex flex-column justify-content-between">
                <div>
                    <h5>👤 الأدمن الحالي</h5>
                    <h4><?php echo e(auth()->user()->name); ?></h4>
                </div>
                <div class="mt-3">
                    <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-sm btn-primary w-100 mb-2">
                        ➕ إضافة أدمن جديد
                    </a>
                    <a href="<?php echo e(route('admin.users')); ?>" class="btn btn-sm btn-outline-secondary w-100">
                        📋 إدارة الحسابات
                    </a>
                </div>
            </div>
        </div>
    </div>

</div>



<!-- آخر السحوبات -->
<div class="mb-5">
    <h4 class="fw-bold mb-3">سحوبات الأدمن</h4>

    <?php if($campaigns->count()): ?>
        <div class="table-responsive">
            <table class="table table-bordered table-hover text-center">
                <thead class="table-info">
                    <tr>
                        <th>#</th>
                        <th>اسم الحملة</th>
                        <th>الوصف</th>
                        <th>تاريخ البداية</th>
                        <th>تاريخ النهاية</th>
                        <th>الحالة</th>
                        <th>إجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($campaign->name); ?></td>
                            <td><?php echo e($campaign->description); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($campaign->start_date)->format('Y-m-d')); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($campaign->end_date)->format('Y-m-d')); ?></td>
                            <td>
                                <?php if($campaign->draw_done): ?>
                                    <span class="badge bg-danger">منتهية</span>
                                <?php elseif(\Carbon\Carbon::now()->lt($campaign->start_date)): ?>
                                    <span class="badge bg-secondary">قادمة</span>
                                <?php else: ?>
                                    <span class="badge bg-success">نشطة</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.giveaway.campaign.edit', $campaign->id)); ?>" class="btn btn-sm btn-primary">✏️ تعديل</a>
                                <form action="<?php echo e(route('admin.giveaway.campaign.destroy', $campaign->id)); ?>" method="POST" class="d-inline delete-form">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="btn btn-sm btn-danger btn-delete">🗑️ حذف</button>
</form>

   <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const deleteForms = document.querySelectorAll('.delete-form');

    deleteForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault(); // منع الفورم من الإرسال مباشرة

            Swal.fire({
                title: 'هل أنت متأكد؟',
                text: "لن تتمكن من التراجع عن هذا الإجراء!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'نعم، احذف!',
                cancelButtonText: 'إلغاء'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit(); // إرسال الفورم إذا ضغط على نعم
                }
            });
        });
    });
});
</script>

                                
                                
<?php if(!$campaign->draw_done && $campaign->entries->count()): ?>
    <a href="<?php echo e(route('admin.giveaway.draw.page', $campaign->id)); ?>" 
       class="btn btn-sm btn-success">
       🎯 تنفيذ السحب
    </a>
<?php endif; ?>



                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p class="text-muted">لا توجد سحوبات حتى الآن.</p>
        <a href="<?php echo e(route('admin.giveaway.campaign.create')); ?>" class="btn btn-success mt-2">➕ إضافة حملة جديدة</a>
    <?php endif; ?>
</div>





    <!-- آخر المشاركين -->
    <div class="mb-5">
        <h4 class="fw-bold mb-3">آخر المشاركين في السحب</h4>
        <?php if($latestEntries->count()): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover text-center">
                    <thead class="table-warning">
                        <tr>
                            <th>#</th>
                            <th>الاسم</th>
                            <th>الهاتف</th>
                            <th>تاريخ المشاركة</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $latestEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($entry->name); ?></td>
                            <td><?php echo e($entry->phone); ?></td>
                            <td><?php echo e($entry->created_at->format('Y-m-d H:i')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <a href="<?php echo e(route('admin.giveaway')); ?>" class="btn btn-warning mt-2">عرض كل المشاركين</a>
        <?php else: ?>
            <p class="mt-3 text-muted">لا يوجد مشاركين حتى الآن.</p>
        <?php endif; ?>
    </div>

    <!-- آخر المستخدمين -->
    <div class="mb-5">
        <h4 class="fw-bold mb-3">آخر المستخدمين</h4>
        <div class="table-responsive">
            <table class="table table-bordered table-hover text-center">
                <thead class="table-primary">
                    <tr>
                        <th>#</th>
                        <th>الاسم</th>
                        <th>البريد</th>
                        <th>تاريخ التسجيل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $latestUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->created_at->format('Y-m-d H:i')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <a href="<?php echo e(route('admin.users')); ?>" class="btn btn-primary mt-2">عرض كل المستخدمين</a>
    </div>

    <!-- آخر الرسائل -->
    <div class="mb-5">
        <h4 class="fw-bold mb-3">آخر رسائل الزبائن</h4>
        <div class="table-responsive">
            <table class="table table-bordered table-hover text-center">
                <thead class="table-success">
                    <tr>
                        <th>#</th>
                        <th>الاسم</th>
                        <th>الهاتف</th>
                        <th>الرسالة</th>
                        <th>التاريخ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $latestMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($msg->name); ?></td>
                        <td><?php echo e($msg->phone); ?></td>
                        <td><?php echo e($msg->topic); ?></td>
                        <td><?php echo e($msg->created_at->format('Y-m-d H:i')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <a href="<?php echo e(route('admin.messages')); ?>" class="btn btn-success mt-2">عرض كل الرسائل</a>
    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\HP\hotel_booking\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>