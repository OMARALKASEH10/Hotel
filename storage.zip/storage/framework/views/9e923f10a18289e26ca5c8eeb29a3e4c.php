<nav class="navbar navbar-expand-lg sticky-top bg-white shadow-sm" style="direction: rtl;">
    <div class="container">
        <div class="d-flex align-items-center">
<a class="navbar-brand d-flex align-items-center" href="<?php echo e(route('home')); ?>">
    <img src="<?php echo e(asset('images/HotelLogo.jpeg')); ?>" 
         alt="Logo" 
         class="me-2 rounded-circle" 
         style="width: 45px; height: 45px; object-fit: cover; border: 2px solid #198754;">
    
    <span class="fw-bold text-success" style="font-size: 1.2rem;">فندق مجد الضيافة</span>
</a>

            <?php if(auth()->guard()->guest()): ?>
                <ul class="navbar-nav ms-3">
                    <li class="nav-item">
<a class="nav-link fw-bold text-dark" href="<?php echo e(route('login')); ?>">
    تسجيل الدخول / إنشاء حساب
</a>

                    </li>
                </ul>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
                <ul class="navbar-nav ms-3">
                    <li class="nav-item">
                        <span class="nav-link text-muted">مرحباً، <?php echo e(Auth::user()->name); ?></span>
                    </li>
                </ul>
            <?php endif; ?>
        </div>

        <?php if(auth()->guard()->check()): ?>
<form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
    <?php echo csrf_field(); ?>
    <button type="submit" class="btn btn-outline-danger btn-sm rounded-pill">
        <i class="fas fa-sign-out-alt"></i> تسجيل الخروج
    </button>
</form>
<?php endif; ?>

<?php if(auth()->guard()->check()): ?>
    <?php if(auth()->user()->is_admin): ?>
        <a href="<?php echo e(route('admin.dashboard')); ?>"
           class="btn btn-success btn-sm rounded-pill me-2">
            لوحة التحكم
        </a>
    <?php endif; ?>
<?php endif; ?>



        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>


            <ul class="navbar-nav" id="nav-links-container">
                <li class="nav-item"><a class="nav-link" href="#home">الرئيسية</a></li>
                <li class="nav-item"><a class="nav-link" href="#about">من نحن</a></li>
                <li class="nav-item"><a class="nav-link" href="#services">خدماتنا</a></li>
                <li class="nav-item"><a class="nav-link" href="#vision">رؤيتنا</a></li>
                <li class="nav-item"><a class="nav-link" href="#location">موقعنا</a></li>
                <li class="nav-item"><a class="nav-link" href="#contact">تواصل معنا</a></li>
            </ul>
    </div>
</nav>
<?php /**PATH C:\Users\HP\hotel_booking\resources\views/partials/navbar.blade.php ENDPATH**/ ?>