<svg viewBox="0 0 316 316" xmlns="http://www.w3.org/2000/svg" {{ $attributes }}>
    
</svg>

<img src="{{ asset('images/HotelLogo.jpeg') }}" class="w-20 h-20" alt="Logo">