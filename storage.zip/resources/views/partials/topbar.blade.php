<div class="top-bar d-none d-md-block">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center gap-4">
            <a href="https://www.facebook.com/omar.alkaseh.2025" target="_blank">
                <i class="fab fa-facebook-f"></i>
            </a>
            <div class="top-bar-item">
                <span>{{ $phone }}</span>
                <i class="fas fa-phone-alt" style="transform: scaleX(-1);"></i>
            </div>
        </div>
        <div class="d-flex align-items-center gap-4">

        <div class="top-bar-item">
            <span>{{ $full_working_schedule }}</span>
            <i class="far fa-clock"></i>
        </div>


            <div class="top-bar-item">
                <span>ليبيا</span>
                <i class="fas fa-map-marker-alt"></i>
            </div>
        </div>
    </div>
</div>
